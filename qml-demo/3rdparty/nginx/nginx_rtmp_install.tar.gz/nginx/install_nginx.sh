#!/bin/bash
cd nginx-1.19.8
sudo apt-get install openssl
sudo apt-get install libssl-dev
sudo apt-get install libssl0.9.8
./configure --prefix=/usr/local/nginx --add-module=../nginx-rtmp-module --with-http_ssl_module 
make
sudo make install
sudo cp nginx.conf /usr/local/nginx/conf/
sudo cp nginx.service /lib/systemd/system/
sudo systemctl enable nginx
sudo systemctl start nginx
